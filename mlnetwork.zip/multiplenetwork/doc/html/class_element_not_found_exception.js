var class_element_not_found_exception =
[
    [ "ElementNotFoundException", "class_element_not_found_exception.html#ad21e23268542ce1670189a97ac9a355d", null ],
    [ "~ElementNotFoundException", "class_element_not_found_exception.html#acb2ae0d579c7b9dcb6179d06a855e321", null ],
    [ "what", "class_element_not_found_exception.html#a96cadc7c34010e185b32d230974b4f40", null ]
];