var searchData=
[
  ['name',['name',['../classmlnet_1_1named__component.html#a3015f6650729352abae8fb01e7ee7ca7',1,'mlnet::named_component::name()'],['../classmlnet_1_1_m_l_network.html#aa2e1496321423e15a8e97e0daed30ca7',1,'mlnet::MLNetwork::name()']]]
];
