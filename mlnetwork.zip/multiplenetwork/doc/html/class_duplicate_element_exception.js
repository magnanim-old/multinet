var class_duplicate_element_exception =
[
    [ "DuplicateElementException", "class_duplicate_element_exception.html#ab1804ab13d350d893d3d003f13035232", null ],
    [ "~DuplicateElementException", "class_duplicate_element_exception.html#ad6ce832dd25ad9e0d2c7c28617bf9cf2", null ],
    [ "what", "class_duplicate_element_exception.html#a5021dd1ab2a52d557f04e55fb792de47", null ]
];