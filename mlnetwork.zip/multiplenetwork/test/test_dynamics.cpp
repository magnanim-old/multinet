/*
 * testNetwork.cpp
 *
 * Created on: Feb 7, 2014
 * Author: matteomagnani
 * Version: 0.0.1
 */

#include "test.h"
#include "mlnetwork.h"
#include <iostream>
#include <string>

using namespace mlnet;

void test_dynamics() {

	/*
	test_begin("Spreading");
	std::cout << "Reading the multilayer network...";
	MLNetworkSharedPtr mnet = read_multilayer("data/aucs.mpx","aucs",',');
	std::cout << "done!" << std::endl;

	matrix<long> stats = sir(mnet,.1,3,1000);

	for (long ts=0; ts<1000; ts++) {
		std::cout << " S:" << stats[0][ts];
		std::cout << " I:" << stats[1][ts];
		std::cout << " R:" << stats[2][ts] << std::endl;
	}

	test_end("Spreading");
*/
}


