/*
 * EvolutionModel.cpp
 *
 *  Created on: 13/ago/2013
 *      Author: matteo.magnani
 */

#include "generation.h"
#include <set>
#include <iostream>

namespace mlnet {

EvolutionModel::~EvolutionModel() {}

}
