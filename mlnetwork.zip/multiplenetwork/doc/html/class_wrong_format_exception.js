var class_wrong_format_exception =
[
    [ "WrongFormatException", "class_wrong_format_exception.html#ac4629be19e1e2238a78a26a36b460d44", null ],
    [ "~WrongFormatException", "class_wrong_format_exception.html#a09d1c47e684c2528f1b4243d30f08273", null ],
    [ "what", "class_wrong_format_exception.html#a26013218831b9785f02bd5c26e938492", null ]
];