var classmlnet_1_1_attribute =
[
    [ "Attribute", "classmlnet_1_1_attribute.html#a51e4b9bb6f82914ffb6be78a4c28ab52", null ],
    [ "name", "classmlnet_1_1_attribute.html#acac4019686c3a0a1c4362eea4d8e12e9", null ],
    [ "type", "classmlnet_1_1_attribute.html#ab9a7df6d77100640dfba5dcbf82aa977", null ],
    [ "type_as_string", "classmlnet_1_1_attribute.html#a0eb1239e4b715ce506129842387e5509", null ]
];