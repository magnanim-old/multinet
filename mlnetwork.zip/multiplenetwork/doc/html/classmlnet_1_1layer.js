var classmlnet_1_1layer =
[
    [ "layer", "classmlnet_1_1layer.html#a4b3b77912bdb71f481028174e22f5a25", null ],
    [ "to_string", "classmlnet_1_1layer.html#a3a7efb6528fc88b0e093957c66830bd5", null ]
];