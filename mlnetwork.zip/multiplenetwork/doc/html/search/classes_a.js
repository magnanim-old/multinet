var searchData=
[
  ['operationnotsupportedexception',['OperationNotSupportedException',['../class_operation_not_supported_exception.html',1,'']]]
];
