var class_operation_not_supported_exception =
[
    [ "OperationNotSupportedException", "class_operation_not_supported_exception.html#ab6f7474f05c4b91ac0f31c9e852bfedb", null ],
    [ "~OperationNotSupportedException", "class_operation_not_supported_exception.html#a4f2ac08e8c20eb4b82edb165a89e22a2", null ],
    [ "what", "class_operation_not_supported_exception.html#ab6533734842e249902213a809a4d3f78", null ]
];