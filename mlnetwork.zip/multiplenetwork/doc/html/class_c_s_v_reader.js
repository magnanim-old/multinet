var class_c_s_v_reader =
[
    [ "CSVReader", "class_c_s_v_reader.html#a12625f70bff372421197d5d5ce236335", null ],
    [ "~CSVReader", "class_c_s_v_reader.html#ad7faacbcf05d20e0536d237197836f66", null ],
    [ "getNext", "class_c_s_v_reader.html#a66d28a3bf8a3e4ef8a4c5f3fb2a238e8", null ],
    [ "hasNext", "class_c_s_v_reader.html#ae411eb74d89935e02287c499b28a36d6", null ],
    [ "open", "class_c_s_v_reader.html#a26227ceca9cb3e5f761788e9934d4920", null ],
    [ "rowNum", "class_c_s_v_reader.html#a5a3d027966cb33b36c80070f6896c5ab", null ],
    [ "setFieldSeparator", "class_c_s_v_reader.html#ae781c05f137c1745abbf03a7fe09d59a", null ],
    [ "trimFields", "class_c_s_v_reader.html#aabd4741cea3e248340fe6a76f4ddd421", null ]
];