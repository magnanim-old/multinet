var class_wrong_parameter_exception =
[
    [ "WrongParameterException", "class_wrong_parameter_exception.html#a228fb340058bbb9b53adeabc56616099", null ],
    [ "~WrongParameterException", "class_wrong_parameter_exception.html#acec1d305c8013be28a1b195b0f3a4af7", null ],
    [ "what", "class_wrong_parameter_exception.html#a7f79b5c6b6a8ac90bb51e00948d4dc29", null ]
];